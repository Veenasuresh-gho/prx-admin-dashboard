import { GHOService } from '../services/ghosrvs';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, inject, OnInit } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { FormsModule } from '@angular/forms';
import { ghoresult, tags } from '../model/ghomodel';
import { MatDividerModule } from '@angular/material/divider';
import { GHOdropdown } from "../components/dropdown";
import { GHODate } from "./date/date";
import { GHOInput } from "./input/input";

@Component({
    selector: 'gho-components',
    changeDetection: ChangeDetectionStrategy.OnPush,
    template: `
        <table>
    <tr>
        <td>   <gho-dropdown label="Country" [(value)]="cntryid"   [options]="cntry" [filter]="true" 
        appearance=outline></gho-dropdown> </td>
      <!--  <td>   <gho-dropdown label="Specialty" [(ngModel)]="splid"    [options]="spl" appearance=filled></gho-dropdown></td>
         <td>   <gho-date  label="Select Date"  appearance=outline   [(ngModel)] ="dateval" ></gho-date></td>
        <td>   <gho-input  label="First Name" [(data)]  = "fname" ></gho-input></td>
        <td>   <gho-input  label="Last Name" [(data)] = "lname" appearance=filled ></gho-input></td>
 -->    </tr>

    <tr> <td>{{cntryid}}</td><td>{{splid}} </td> <td>{{dateval}}   </td>  <td> {{fname}} </td>  <td> {{lname}} </td></tr>
    </table>

    `,

    imports: [CommonModule, MatTableModule, MatButtonModule, MatPaginatorModule,
        MatFormFieldModule, MatIconModule, MatSelectModule,
        FormsModule, MatDividerModule, GHOdropdown, GHODate, GHOInput],
})
export class GHOComponents implements OnInit {

    selectedOptionId: string = ''; // This will store the value bound by ngModel
    dropdownOptions = [
        { value: '1', label: 'Option A' },
        { value: '2', label: 'Option B' },
        { value: '3', label: 'Option C' }
    ]


    srv = inject(GHOService);
    userid: string = "";
    pw: string = "";
    tv: tags[] = [];
    res: ghoresult = new ghoresult();
    cntry: [] = []
    spl: [] = []
    splid:any;
    cntryid: any = "40";
    fname: string = "jaison";
    lname: string = "joseph";
    dateval: string = "12/12/2025"

    onDateRangeChange(e: any) {
    }

    getcntry(v: string) {
        this.cntry = [];
        this.tv = [{ T: 'c10', V: '83' }];
        this.srv.getdata('lists', this.tv).subscribe(r => {
            this.res = r;
            if (r.Status === 1 && r.Data?.length > 0) {
                this.cntry = r.Data[0]
            }
        });
    }

    getspl() {
        this.cntry = [];
        this.tv = [{ T: 'c10', V: '97' }];
        this.srv.getdata('lists', this.tv).subscribe(r => {
            this.res = r;
            if (r.Status === 1 && r.Data?.length > 0) {
                this.spl = r.Data[0]
            }
        });
    }


    ngOnInit(): void {
        this.getcntry("83")
        this.getspl()
    }
}