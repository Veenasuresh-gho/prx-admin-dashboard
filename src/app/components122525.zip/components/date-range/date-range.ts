import { CommonModule } from '@angular/common';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';

export interface DateFilterResult {
  label: string;
  value: string;
  from?: string | null;
  to?: string | null;
}

@Component({
  selector: 'app-date-range',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './date-range.html',
  styleUrl: '../dropdown.css'
})
export class DateRange implements OnInit {

  @Output() selectionChange = new EventEmitter<DateFilterResult>();

  isOpen = false;

  presets: { label: string; value: string }[] = [];
  selectedType: string | null = null;

  fromDate: string | null = null;
  toDate: string | null = null;

  ngOnInit(): void {
    this.presets = [
      { label: 'Today', value: 'today' },
      { label: 'Last 7 days', value: '7days' },
      { label: 'Last 30 days', value: '30days' },
      { label: 'This year', value: 'year' },
      { label: 'Last year', value: 'lastyear' },
      { label: 'Custom date ', value: 'custom' }
    ];
  }

  toggleDropdown(): void {
    this.isOpen = !this.isOpen;
  }

  getLabel(value: string): string {
    return this.presets.find(p => p.value === value)?.label ?? 'Select Date Range';
  }

  onPresetClick(preset: { label: string; value: string }): void {
    this.selectedType = preset.value;

    if (preset.value !== 'custom') {
      this.selectionChange.emit({
        label: preset.label,
        value: preset.value
      });

      this.closeDropdown();
    }
  }

  applyCustom(): void {
    if (!this.fromDate || !this.toDate) return;

    this.selectionChange.emit({
      label: 'Custom date range',
      value: 'custom',
      from: this.fromDate,
      to: this.toDate
    });

    this.closeDropdown();
  }

  clearSelection(): void {
    this.selectedType = null;
    this.fromDate = null;
    this.toDate = null;

    this.selectionChange.emit({
      label: 'Select Date Range',
      value: ''
    });
  }

  closeDropdown(): void {
    this.isOpen = false;
  }
}
