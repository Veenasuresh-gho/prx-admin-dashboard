import { CommonModule } from '@angular/common';
import { Component, forwardRef, Input, model, ElementRef, SimpleChanges, HostListener, } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR, FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

@Component({
    selector: 'app-custom-select',
    templateUrl: `./input/ddltest.html`,
    styleUrl: './dropdown.css',
    imports: [
        CommonModule,
        FormsModule, // Add FormsModule here
        // ... other modules
    ],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => CustomSelectComponent),
            multi: true
        }
    ]
})
export class CustomSelectComponent implements ControlValueAccessor {
    constructor(private el: ElementRef) { }
    @Input() options: any[] = [];
    @Input() placeholder: string = 'Select an option';
    @Input() showclear: boolean = true;
    @Input() appearance: string = "outline"
    @Input() label: string = "";
    @Input() filter: boolean = true;
    public value: string="";
    public disabled: boolean = false;
    listdata: { label: string; value: string }[] = [];
    isOpen = false;
    selectedtxt :string ="";

    gettxt(){
        if (this.datavalid()) {return this.selectedtxt } 
        else {return this.label} 
    }

    toggleDropdown(): void {
        this.isOpen = !this.isOpen;
    }

    clear() { this.value = ""; }

    closeDropdown(): void {
        this.isOpen = false;
    }

    datavalid() {
        if (this.value === undefined || this.value == null || this.value == "" || this.value == "0") {
            return false;
        }
        else { return true; }
    }
    ngOnChanges(changes: SimpleChanges) {
        if (changes['options']) {
            this.listdata = [];
            const allKeys = Array.from(
                new Set(this.options.flatMap(item => Object.keys(item)))
            );

            for (let i: number = 0; i < this.options.length; i++) {
                if (allKeys.length == 1) {
                    this.listdata.push({ label: this.options[i][allKeys[0]], value: this.options[i][allKeys[0]] })
                }
                else {
                    this.listdata.push({ label: this.options[i][allKeys[1]], value: this.options[i][allKeys[0]] })
                }
            }
        }
    }


    // Functions to call when the value changes or the control is touched
    onChange: any = () => { };
    onTouched: any = () => { };

    // Registers a callback function that is called when the control's value changes in the UI
    registerOnChange(fn: any): void {
        debugger;
        this.isOpen=false;
        this.onChange = fn;
    }

    // Registers a callback function that is called whenever the control receives a touch event
    registerOnTouched(fn: any): void {
        this.onTouched = fn;
    }

    // Writes a new value to the element
    writeValue(value: any): void {
        this.value = value;
    }

    // Sets the disabled state of the control
    setDisabledState?(isDisabled: boolean): void {
        this.disabled = isDisabled;
    }


    onSelectionChange1(v:any)
    {
        this.isOpen=false;
        this.selectedtxt = v.label;
        const newValue = v.value;
        this.value = newValue;
        this.onChange(newValue); // Notify Angular forms about the change
        this.onTouched(); // Mark the control as touched
    }

    // Custom method to handle selection change in the template
    onSelectionChange(event: Event): void {
        const selectElement = event.target as HTMLSelectElement;
        const newValue = selectElement.value;
        this.value = newValue;
        this.onChange(newValue); // Notify Angular forms about the change
        this.onTouched(); // Mark the control as touched
    }

     @HostListener('document:click', ['$event'])
    onOutsideClick(event: Event): void {
        if (!this.el.nativeElement.contains(event.target)) {
            this.isOpen = false;
        }
    }


     getclearclass()
  {
    if (this.appearance == "outline")
    {
      if(this.datavalid() && this.showclear) { return "input-outline-filter-img"  ;}
    }
    else { return "input-mat-img " ;}
    return "input-mat";
  }
  getclass() {
    if (this.appearance == "outline")
    {
      let css = " d-flex  gap-3"
      if (!this.filter) { css = "input-outline" }

      if (this.filter) 
        { if (!this.datavalid()) { css = "input-outline" }}

      if (this.filter) 
        { if (this.datavalid()) { css = "input-outline-filter " }}

      if(!this.showclear) { css = "input-outline" }

      return  css+" input d-flex  gap-3 " 
    }
    else{
      return "input-mat d-flex  gap-3 "
    }
  }

}
