import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, model, ElementRef, EventEmitter, Input, OnInit }
    from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from "@angular/material/card";
import { provideNativeDateAdapter } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { DatePipe } from '@angular/common';
export interface DateFilterResult {
    label: string;
    value: string;
    from?: string | null;
    to?: string | null;
}

@Component({
    selector: 'gho-input',
    standalone: true,
    imports: [CommonModule, FormsModule, MatDatepickerModule, MatCardModule],
    templateUrl: './input.html',
    styleUrl: '../dropdown.css',
    providers: [provideNativeDateAdapter(), DatePipe],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GHOInput implements OnInit {
    constructor(private el: ElementRef, private cdr: ChangeDetectorRef, private datePipe: DatePipe) { }
    data = model<string>("");
    @Input() list: [] = [];
    @Input() label: string = "";
    @Input() appearance: string = "outline"
    @Input() filter: boolean = true;
    @Input() showclear: boolean = true;
     getclass() {
    if (this.appearance == "outline")
    {
      let css = ""
      if (!this.filter && !this.datavalid()) { css = "ghoddl-border" }
      if (!this.filter && this.datavalid()) { css = "ghoddl-no-filter" }
      if (!this.showclear) { css = "ghoddl-border" }

      if (this.filter && !this.datavalid()) { css = "ghoddl-border" }
      if (this.filter && this.datavalid() && this.showclear) { css = "ghoddl-filter filterd" }
      return "ghoinput d-flex  gap-3 " + css;
    }
    else{
      return "ghoinput-mat d-flex  gap-3 "
    }
    }

    datavalid() {
    if (this.data === undefined || this.data == null ) {
      return false;
    }
    else { return true; }
  }


    ngOnInit(): void {
    }

}
