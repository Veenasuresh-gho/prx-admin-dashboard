import { CommonModule } from '@angular/common';
import {
  AfterViewChecked, AfterViewInit, ChangeDetectionStrategy, model,ModelSignal,
  ChangeDetectorRef, Component, ElementRef, EventEmitter, forwardRef, HostListener, Input, 
  NgZone, OnInit, Output, SimpleChanges
} from '@angular/core';
import { ControlValueAccessor, FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { MatAnchor } from "@angular/material/button";
import { reduce } from 'rxjs';

export interface DateFilterResult {
  label: string;
  value: string;
  from?: string | null;
  to?: string | null;
}

@Component({
  selector: 'gho-dropdown',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, FormsModule],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => GHOdropdown),
      multi: true
    }
  ],
  template: `
<div style="height: 55px !important;">{{getvalue()}}
    <div style="height: 15px !important;">
      
        @if(datavalid())
        {
        <div [ngStyle]="{ margin: '-2px 5px' }" class="txt-sm bold">
            <span style="background-color: transparent; position:inherit">{{label}} </span>
        </div>
        }
    </div>
    <table>
        <tr>
            <td>
                <div (click)="toggleDropdown()" [ngClass]="getclass()">
                    <span>{{selectedtxt}}</span>
                    <i class="bi bi-caret-down-fill arrow-icon" [class.rotate]="isOpen"></i>
                </div>
            </td>
            @if(filter && datavalid() )
            {
            <td>
                <div (click)="clear()" [ngClass]="getclearclass()">
                    <i class="bi bi-x-lg "></i>
                </div>
            </td> }
        </tr>
    </table>
</div>
@if(isOpen){
<div class="dropdown-menu show  border  mat-elevation-z8">
    <div class="list-panel">
      
        @for (dlitem of listdata; track dlitem) {
        <div class="list-item " (click)="onSelectionChange(dlitem)" [class.list-item-selected]="dlitem.value == getvalue()">
            <table class="w100">
                <tr>
                    <td>
                        {{ dlitem.label }}
                    </td>
                    @if(dlitem.value == value()){
                    <td class="right" style="width:30px;"> <i class="bi bi-check2"></i> </td>}
                </tr>
            </table>
        </div>
        }
    </div>
    <table class=w100>
        <tr class="bt ">
            <td class="p10" (click)="clear()"><span matButton class="ghoddl-btn  "> Clear </span> </td>
            <td class="p10" (click)="closeDropdown()"><span matButton class="ghoddl-btn  "> Cancel </span> </td>
        </tr>
    </table>
</div>
}
`,
  styleUrl: './dropdown.css',
})
export class GHOdropdown {
  constructor(private el: ElementRef, private cdr: ChangeDetectorRef, private ngZone: NgZone) { }
  @Input() options: any[] = [];
  @Input() placeholder: string = 'Select an option';
  @Input() showclear: boolean = true;
  @Input() appearance: string = "outline"
  @Input() label: string = "";
  @Input() filter: boolean = true;
  value = model<string>(""); 
  public disabled: boolean = false;
  listdata: { label: string; value: string }[] = [];
  isOpen = false;
  selectedtxt: string = "";

  getvalue()
  {
    return this.value().toString();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['options']) {
      this.listdata = [];
      const allKeys = Array.from(
        new Set(this.options.flatMap(item => Object.keys(item)))
      );

      for (let i: number = 0; i < this.options.length; i++) {
        if (allKeys.length == 1) {
          this.listdata.push({ label: this.options[i][allKeys[0]], value: this.options[i][allKeys[0]] })
        }
        else {
          this.listdata.push({ label: this.options[i][allKeys[1]], value: this.options[i][allKeys[0]] })
        }
      }
    }
  }

  datavalid() {
    let v = this.value();
    let rt = false;
    if (this.value !== undefined && this.value !== null && v !== "" && v !== "0") {
      let lb = this.listdata.find(l => l.value == v);
      if (lb !== undefined && lb !== null) {
        this.selectedtxt = lb.label;
        rt = true;
      }
      else {
        this.selectedtxt = this.label;
      }
    }
    else {
      this.selectedtxt = this.label;
    }
    return rt
  }
 // Writes a new value to the element
    writeValue(value: any): void {
      this.value = value;
    
    }
  

  /* 
     ngOnInit() {
      this.datavalid();
         this.cdr.detectChanges();
     }
  
   
  
  
  
    ngAfterViewChecked()
    {
      this.cdr.detectChanges();
    } */

  toggleDropdown(): void {
    this.isOpen = !this.isOpen;
  }

  clear() {
    this.value.set("");
    this.selectedtxt = this.label;
    this.onChange(this.value);
    this.onTouched();
    this.isOpen = false;
  }

  closeDropdown(): void {
    this.isOpen = false;
  }






  // Functions to call when the value changes or the control is touched
  onChange: any = () => { };
  onTouched: any = () => { };

  // Registers a callback function that is called when the control's value changes in the UI
  registerOnChange(fn: any): void {
    this.isOpen = false;
    this.onChange = fn;
  }

  // Registers a callback function that is called whenever the control receives a touch event
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }


  // Sets the disabled state of the control
  setDisabledState?(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }


  onSelectionChange(v: any) {
    this.isOpen = false;
    this.selectedtxt = v.label;
    if (v.label === undefined || v.label === null) { this.selectedtxt = v.value }
    const newValue = v.value;
    this.value = newValue;
    this.datavalid();
    this.onChange(newValue); // Notify Angular forms about the change
    this.onTouched(); // Mark the control as touched

  }



  @HostListener('document:click', ['$event'])
  onOutsideClick(event: Event): void {
    if (!this.el.nativeElement.contains(event.target)) {
      this.isOpen = false;
    }
  }


  getclearclass() {
    if (this.appearance == "outline") {
      if (this.datavalid() && this.showclear) { return "input-outline-filter-img"; }
    }
    else { return "input-mat-img "; }
    return "input-mat";
  }
  getclass() {
    if (this.appearance == "outline") {
      let css = " d-flex  gap-3"
      if (!this.filter) { css = "input-outline" }

      if (this.filter) { if (!this.datavalid()) { css = "input-outline" } }

      if (this.filter) { if (this.datavalid()) { css = "input-outline-filter " } }

      if (!this.showclear) { css = "input-outline" }

      return css + " input d-flex  gap-3 "
    }
    else {
      return "input-mat d-flex  gap-3 "
    }
  }

}